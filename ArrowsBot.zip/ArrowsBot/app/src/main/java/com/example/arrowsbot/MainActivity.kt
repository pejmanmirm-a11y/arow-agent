package com.example.arrowsbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val REQ = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val info = TextView(this).apply {
            textSize = 16f
            text = "1) سرویس دسترسی را روشن کن (Arrows Bot).\n" +
                "2) بازی را باز کن و مرحله را روی صفحه بگذار.\n" +
                "3) برگرد به این برنامه و «شروع حل» را بزن.\n" +
                "بعد از تأیید، ۵ ثانیه وقت داری برگردی به بازی."
        }
        val b1 = Button(this).apply {
            text = "۱. فعال‌سازی سرویس دسترسی"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val b2 = Button(this).apply {
            text = "۲. شروع حل"
            setOnClickListener {
                if (TapService.instance == null) {
                    info.text = "ابتدا سرویس دسترسی را فعال کن (دکمه‌ی ۱)."
                } else {
                    val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
                }
            }
        }
        root.addView(info); root.addView(b1); root.addView(b2)
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
