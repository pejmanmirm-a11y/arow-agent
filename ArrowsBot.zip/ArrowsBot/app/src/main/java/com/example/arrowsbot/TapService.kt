package com.example.arrowsbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapService : AccessibilityService() {
    companion object {
        var instance: TapService? = null
        private const val BATCH = 8
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Taps all points in order, BATCH taps per gesture. */
    fun tapAll(points: List<Pt>, onDone: () -> Unit) {
        main.post { sendBatch(points, 0, onDone) }
    }

    private fun sendBatch(points: List<Pt>, from: Int, onDone: () -> Unit) {
        if (from >= points.size) { onDone(); return }
        val to = minOf(from + BATCH, points.size)
        val builder = GestureDescription.Builder()
        for (i in from until to) {
            val p = Path().apply { moveTo(points[i].x, points[i].y) }
            builder.addStroke(GestureDescription.StrokeDescription(p, (i - from) * 45L, 30L))
        }
        val ok = dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { main.postDelayed({ sendBatch(points, to, onDone) }, 150) }
            override fun onCancelled(g: GestureDescription?) { main.postDelayed({ sendBatch(points, to, onDone) }, 150) }
        }, null)
        if (!ok) onDone()
    }
}
