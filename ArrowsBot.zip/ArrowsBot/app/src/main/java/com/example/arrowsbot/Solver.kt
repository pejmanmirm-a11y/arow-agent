package com.example.arrowsbot

import kotlin.math.abs

data class Pt(val x: Float, val y: Float)

object Solver {
    private class Grid(val x0: Double, val y0: Double, val p: Double, val nc: Int, val nr: Int)
    private class Arrow(val nodes: Set<Int>, val head: Int, val dr: Int, val dc: Int)

    fun solve(px: IntArray, w: Int, h: Int): Pair<List<Pt>, String> {
        val m = BooleanArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            m[i] = r < 80 && g < 80 && b < 130 && (b - r) > 25
        }
        val grid = calibrate(m, w, h) ?: return Pair(emptyList(), "صفحه‌ی بازی پیدا نشد")
        val arrows = findArrows(m, w, h, grid)
        val owner = HashMap<Int, Int>()
        arrows.forEachIndexed { i, a -> for (n in a.nodes) owner[n] = i }
        val alive = sortedSetOf<Int>().apply { addAll(arrows.indices) }
        val order = ArrayList<Int>()
        fun free(i: Int): Boolean {
            val a = arrows[i]
            var r = a.head / grid.nc + a.dr; var c = a.head % grid.nc + a.dc
            while (r in 0 until grid.nr && c in 0 until grid.nc) {
                val o = owner[r * grid.nc + c]
                if (o != null && o in alive && o != i) return false
                r += a.dr; c += a.dc
            }
            return true
        }
        var progress = true
        while (progress) {
            progress = false
            for (i in alive.toList()) {
                if (free(i)) { alive.remove(i); order.add(i); progress = true }
            }
        }
        val pts = order.map {
            val hd = arrows[it].head
            Pt((grid.x0 + (hd % grid.nc) * grid.p).toFloat(), (grid.y0 + (hd / grid.nc) * grid.p).toFloat())
        }
        return Pair(pts, "شبکه ${grid.nc}×${grid.nr} | فلش ${arrows.size} | قابل حل ${order.size} | گیرکرده ${alive.size}")
    }

    private fun clusters(idx: List<Int>): List<Double> {
        val out = ArrayList<Double>(); var cur = ArrayList<Int>()
        for (v in idx) {
            if (cur.isNotEmpty() && v - cur.last() > 2) { out.add(cur.average()); cur = ArrayList() }
            cur.add(v)
        }
        if (cur.isNotEmpty()) out.add(cur.average())
        return out
    }

    private fun fit(c: List<Double>): Triple<Double, Double, Int>? {
        if (c.size < 3) return null
        val cmin = c.min(); val span = c.max() - cmin
        var best: Triple<Double, Int, Double>? = null
        for (n in maxOf(5, (span / 40).toInt())..(span / 14).toInt()) {
            val p = span / n
            var s = 0.0
            for (v in c) { val q = (v - cmin) / p; s += abs(q - Math.round(q).toDouble()) }
            val res = s / c.size * p
            if (best == null || res < best.first - 1e-9) best = Triple(res, n, p)
        }
        val b = best ?: return null
        return Triple(cmin, b.third, b.second + 1)
    }

    private fun calibrate(m: BooleanArray, w: Int, h: Int): Grid? {
        val rowCount = IntArray(h)
        for (y in 0 until h) for (x in 0 until w) if (m[y * w + x]) rowCount[y]++
        val ys = (0 until h).filter { rowCount[it] > w * 0.15 }
        if (ys.isEmpty()) return null
        val y0 = ys.first(); val y1 = ys.last()
        val colCount = IntArray(w)
        for (y in y0..y1) for (x in 0 until w) if (m[y * w + x]) colCount[x]++
        val xs = (0 until w).filter { colCount[it] > (y1 - y0) * 0.15 }
        if (xs.isEmpty()) return null
        val x0 = xs.first(); val x1 = xs.last()
        val subH = y1 - y0 + 1; val subW = x1 - x0 + 1
        val rowSub = IntArray(h)
        for (y in y0..y1) for (x in x0..x1) if (m[y * w + x]) rowSub[y]++
        val cx = clusters((x0..x1).filter { colCount[it] > subH * 0.25 })
        val cy = clusters((y0..y1).filter { rowSub[it] > subW * 0.25 })
        if (cx.isEmpty() || cy.isEmpty()) return null
        val fx = fit(cx) ?: return null
        val fy = fit(cy) ?: return null
        return Grid(fx.first, fy.first, (fx.second + fy.second) / 2, fx.third, fy.third)
    }

    private fun frac(m: BooleanArray, w: Int, h: Int, x: Double, y: Double, rad: Int): Double {
        val xi = Math.round(x).toInt(); val yi = Math.round(y).toInt()
        var s = 0
        for (dy in -rad..rad) for (dx in -rad..rad) {
            val xx = xi + dx; val yy = yi + dy
            if (xx in 0 until w && yy in 0 until h && m[yy * w + xx]) s++
        }
        val side = 2 * rad + 1
        return s.toDouble() / (side * side)
    }

    private fun findArrows(m: BooleanArray, w: Int, h: Int, g: Grid): List<Arrow> {
        val adj = HashMap<Int, MutableList<Int>>()
        fun add(a: Int, b: Int) {
            adj.getOrPut(a) { ArrayList() }.add(b); adj.getOrPut(b) { ArrayList() }.add(a)
        }
        val ts = doubleArrayOf(0.25, 0.4, 0.5, 0.6, 0.75)
        for (r in 0 until g.nr) for (c in 0 until g.nc) {
            for ((dr, dc) in listOf(0 to 1, 1 to 0)) {
                val r2 = r + dr; val c2 = c + dc
                if (r2 >= g.nr || c2 >= g.nc) continue
                val x1 = g.x0 + c * g.p; val y1 = g.y0 + r * g.p
                val x2 = g.x0 + c2 * g.p; val y2 = g.y0 + r2 * g.p
                if (ts.all { t -> frac(m, w, h, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, 1) > 0.8 })
                    add(r * g.nc + c, r2 * g.nc + c2)
            }
        }
        val seen = HashSet<Int>(); val out = ArrayList<Arrow>()
        for (start in adj.keys.sorted()) {
            if (start in seen) continue
            val comp = ArrayList<Int>(); val st = ArrayDeque<Int>(); st.add(start); seen.add(start)
            while (st.isNotEmpty()) {
                val u = st.removeLast(); comp.add(u)
                for (v in adj[u]!!) if (seen.add(v)) st.add(v)
            }
            val ends = comp.filter { adj[it]!!.size == 1 }
            if (ends.size != 2) continue
            fun width(e: Int): Int {
                val er = e / g.nc; val ec = e % g.nc
                val nb = adj[e]!![0]
                val ux = (nb % g.nc) - ec; val uy = (nb / g.nc) - er
                val ex = g.x0 + ec * g.p; val ey = g.y0 + er * g.p
                var best = 0
                var d = -6
                while (d < 12) {
                    val cx = ex + ux * d; val cy = ey + uy * d
                    var run = 0
                    for (t in -12..12) {
                        val x = Math.round(cx + (-uy) * t).toInt(); val y = Math.round(cy + ux * t).toInt()
                        if (x in 0 until w && y in 0 until h && m[y * w + x]) run++
                    }
                    if (run > best) best = run
                    d += 2
                }
                return best
            }
            val head = ends.maxByOrNull { width(it) }!!
            val nb = adj[head]!![0]
            out.add(Arrow(comp.toSet(), head, head / g.nc - nb / g.nc, head % g.nc - nb % g.nc))
        }
        return out
    }
}
